"""USPTO trademark lookup.

Resolves a brand name to its live registration(s) so the complaint can cite a
real registration number. The safety-critical behavior: when zero or several
LIVE marks match the brand exactly, we NEVER auto-pick — the result flags
`needs_human_selection` and the human chooses. Citing the wrong registration (or
one in an unrelated goods/services class) invalidates the whole complaint.

The HTTP call is a seam. `parse_tsdr_records` maps a raw response into normalized
rows; verify the field mapping against a live USPTO response before trusting it
in production — the shape here reflects the documented TSDR/TMSEARCH fields.
Note: as of 2026-06-18 the USPTO Open Data Portal requires a USPTO.gov account;
public TSDR status lookups do not.
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from urllib.parse import quote_plus


def _norm_owner(name: str) -> str:
    """Normalize an owner name for exact matching: lowercase, drop punctuation."""
    return re.sub(r"[^a-z0-9 ]", "", (name or "").lower()).strip()

# Official USPTO search is a stateful SPA — it CANNOT be prefilled via URL query
# (verified: the results URL carries no query). So the prefilled, clickable
# search uses Justia, which indexes USPTO records and DOES take a GET query and
# shows registration/serial numbers. The official link is provided for the human
# to verify the exact registration before citing it.
USPTO_OFFICIAL_SEARCH = "https://tmsearch.uspto.gov/search/search-information"


def justia_search_url(mark: str) -> str:
    """A prefilled, clickable trademark search for `mark` (USPTO-indexed)."""
    return "https://trademarks.justia.com/search?q=" + quote_plus(mark)


def build_trademark_search_urls(brand: str, variants: list[str] | None = None) -> dict:
    """Prefilled search URLs for the brand + each family variant, plus official."""
    marks = [brand] + list(variants or [])
    return {
        "marks": marks,
        "prefilled": [justia_search_url(m) for m in marks],
        "official": USPTO_OFFICIAL_SEARCH,
    }


def open_trademark_search(build: dict, opener=None, do_open: bool = True) -> list:
    """Pop up the browser on each prefilled search. `opener` injectable for tests."""
    if not do_open:
        return []
    if opener is None:
        import webbrowser
        opener = webbrowser.open
    opened = []
    for url in build["prefilled"]:
        opener(url)
        opened.append(url)
    return opened

# Status tokens that mean the registration is NOT enforceable.
_DEAD_TOKENS = ("DEAD", "ABANDON", "CANCEL", "EXPIRED", "LAPSED")


@dataclass
class TrademarkRecord:
    wordmark: str
    registration_number: str
    serial_number: str
    status: str
    owner: str
    intl_class: str
    live: bool


@dataclass
class LookupResult:
    all_live: list[TrademarkRecord] = field(default_factory=list)
    exact: list[TrademarkRecord] = field(default_factory=list)
    needs_human_selection: bool = True
    chosen: TrademarkRecord | None = None   # auto-selected on exact owner match


def _is_live(status: str) -> bool:
    s = (status or "").upper()
    return not any(tok in s for tok in _DEAD_TOKENS)


def parse_tsdr_records(raw: dict) -> list[TrademarkRecord]:
    """Normalize a TSDR/TMSEARCH-shaped response into TrademarkRecord rows."""
    rows: list[TrademarkRecord] = []
    for t in raw.get("trademarks", []) or []:
        status = t.get("status", "")
        rows.append(TrademarkRecord(
            wordmark=t.get("wordmark", ""),
            registration_number=str(t.get("registrationNumber", "")),
            serial_number=str(t.get("serialNumber", "")),
            status=status,
            owner=t.get("owner", ""),
            intl_class=str(t.get("internationalClass", "")),
            live=_is_live(status),
        ))
    return rows


def select_registrations(records: list[TrademarkRecord], brand: str,
                         owner: str | None = None) -> LookupResult:
    """Filter to live marks and identify exact-wordmark matches.

    Without `owner`: `needs_human_selection` is False only when exactly one live
    mark matches the brand exactly. With `owner`: among the wordmark matches, if
    exactly one has an **exact owner-name match** (case/punctuation-insensitive),
    it is auto-selected (`chosen`) and `needs_human_selection` is False. This is
    the safe auto-prefill rule — it can't select a same-named mark owned by a
    different company.
    """
    brand_norm = brand.strip().lower()
    all_live = [r for r in records if r.live]
    exact = [r for r in all_live if r.wordmark.strip().lower() == brand_norm]

    if owner:
        owner_norm = _norm_owner(owner)
        owner_matches = [r for r in exact if _norm_owner(r.owner) == owner_norm]
        if len(owner_matches) == 1:
            return LookupResult(all_live=all_live, exact=exact,
                                needs_human_selection=False,
                                chosen=owner_matches[0])
        return LookupResult(all_live=all_live, exact=exact,
                            needs_human_selection=True, chosen=None)

    chosen = exact[0] if len(exact) == 1 else None
    return LookupResult(all_live=all_live, exact=exact,
                        needs_human_selection=(len(exact) != 1), chosen=chosen)


def parse_justia_results(text: str) -> list[TrademarkRecord]:
    """Parse a Justia trademark search results page (text) into attributed rows.

    Each hit is: MARK line, 'Filed: <date>', goods, 'Owned by: <owner>',
    'Serial Number: <n>'. Live status isn't in the summary — confirm via TSDR.
    """
    pat = re.compile(
        r"(?P<mark>[^\n]+?)\n\s*\nFiled:.*?Owned by:\s*(?P<owner>.+?)\s*\n\s*"
        r"Serial Number:\s*(?P<serial>\d{7,8})",
        re.S)
    rows: list[TrademarkRecord] = []
    for m in pat.finditer(text):
        rows.append(TrademarkRecord(
            wordmark=m.group("mark").strip(),
            registration_number="",
            serial_number=m.group("serial"),
            status="(Justia summary — confirm on TSDR)",
            owner=m.group("owner").strip(),
            intl_class="",
            live=True,      # summary has no status; TSDR confirms live/dead
        ))
    return rows


def parse_tsdr_status(text: str) -> dict:
    """Extract registration number + live/registered status from TSDR status text."""
    def g(pat: str) -> str:
        m = re.search(pat, text, re.I)
        return m.group(1).strip() if m else ""

    descr = g(r"TM5 Common Status Descriptor:\s*\n+\s*([A-Za-z/ ]+)")
    reg = g(r"US Registration Number:\s*\n?\s*([0-9]{5,8})")
    wordmark = g(r"Mark Literal Elements:\s*\n?\s*([^\n]+)")
    live = "LIVE" in descr.upper() or "LIVE/" in text.upper()
    registered = ("REGISTRATION" in descr.upper()
                  or bool(re.search(r"\bRegistered\b", text)))
    return {"registration_number": reg, "status_descriptor": descr,
            "wordmark": wordmark, "live": live, "registered": registered}


# --- HTTP seam (not exercised in CI) --------------------------------------

def fetch_tsdr(brand: str, api_key: str | None = None) -> dict:
    """Live USPTO lookup by wordmark. Returns raw JSON to feed parse_tsdr_records.

    Endpoint/params intentionally overridable — USPTO has been migrating search
    surfaces (TSDR, TMSEARCH, Open Data Portal). Verify against the live response
    shape and adjust `parse_tsdr_records` if fields differ.
    """
    import requests  # local import: keep module importable without the dep

    base = os.environ.get("USPTO_TSDR_URL", "https://tmsearch.uspto.gov/api/v1/search")
    key = api_key or os.environ.get("USPTO_API_KEY")
    headers = {"Authorization": f"Bearer {key}"} if key else {}
    resp = requests.get(base, params={"query": brand, "type": "wordmark"},
                        headers=headers, timeout=30)
    resp.raise_for_status()
    return resp.json()


_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/125.0 Safari/537.36")


def fetch_justia_results(brand: str) -> str:
    """Fetch Justia search results text for `brand`. Needs a browser — Justia
    403s plain requests. Feed the return to parse_justia_results."""
    from playwright.sync_api import sync_playwright  # optional dep

    with sync_playwright() as pw:
        b = pw.chromium.launch(headless=True)
        pg = b.new_context(user_agent=_UA, locale="en-US").new_page()
        pg.goto(justia_search_url(brand), wait_until="domcontentloaded", timeout=40000)
        pg.wait_for_timeout(4000)
        text = pg.inner_text("body")
        b.close()
    return text


def fetch_tsdr_status(serial: str) -> str:
    """Fetch TSDR status for a serial (plain requests works). Tags stripped to
    text so parse_tsdr_status can read it."""
    import html as _html

    import requests

    r = requests.get(f"https://tsdr.uspto.gov/statusview/sn{serial}",
                     headers={"User-Agent": _UA}, timeout=30)
    r.raise_for_status()
    return _html.unescape(re.sub(r"<[^>]+>", "\n", r.text))
