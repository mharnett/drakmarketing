"""Evidence dossier + pre-filled draft complaint package.

Wires the pieces together: an ad is a complaint candidate only if the mark is in
its copy (`match.matched`), it is not the owner's own ad (`not is_own_brand`),
and its landing-page use is COMPETITIVE (`is_complaint_candidate(bucket)`). The
output is a draft a human reviews and submits — `auto_submit` is always False,
because Google's form is a legal attestation behind a human verification loop.
"""
from __future__ import annotations

from dataclasses import dataclass, field

from scripts.classifier import Bucket, is_complaint_candidate


@dataclass
class Candidate:
    advertiser: str
    trigger_query: str
    matched_text: list[str]
    fields: list[str]
    bucket: str
    landing_url: str
    final_url: str
    screenshot_path: str
    geo: str
    dki_suspected: bool
    headlines: list[str] = field(default_factory=list)


def looks_like_dki(matched_text: list[str], trigger_query: str) -> bool:
    """Heuristic: the served mark echoes the search query -> likely DKI.

    Not proof — a human confirms by noting the term is served for that query.
    """
    q = (trigger_query or "").lower()
    return any(t.lower() in q for t in matched_text if t)


def select_candidates(assessed: list[dict]) -> list[Candidate]:
    """Keep only matched, non-owner, COMPETITIVE ads."""
    out: list[Candidate] = []
    for item in assessed:
        match = item["match"]
        bucket = item["bucket"]
        if not getattr(match, "matched", False):
            continue
        if getattr(match, "is_own_brand", False):
            continue
        if not is_complaint_candidate(bucket):
            continue
        ad = item["ad"]
        out.append(Candidate(
            advertiser=ad.get("advertiser", ""),
            trigger_query=ad.get("trigger_query", ""),
            matched_text=list(getattr(match, "matched_text", [])),
            fields=list(getattr(match, "fields", [])),
            bucket=bucket.value if isinstance(bucket, Bucket) else str(bucket),
            landing_url=item.get("landing_url") or ad.get("final_url", ""),
            final_url=ad.get("final_url", ""),
            screenshot_path=ad.get("screenshot_path", ""),
            geo=ad.get("geo", ""),
            dki_suspected=bool(item.get("dki_suspected", False)),
            headlines=list(ad.get("headlines", [])),
        ))
    return out


def build_draft_package(brand: str, owner: str, registration_numbers: list[str],
                        needs_human_selection: bool, candidates: list[Candidate],
                        complainant: dict, geos: list[str]) -> dict:
    """Assemble the reviewed-then-submitted complaint draft (never auto-filed)."""
    warnings: list[str] = []
    if needs_human_selection or not registration_numbers:
        warnings.append(
            "Trademark registration not auto-selected: confirm the correct LIVE "
            "registration (and that its class covers the goods/services) before filing.")
    if any(c.dki_suspected for c in candidates):
        warnings.append(
            "One or more candidates appear served via dynamic keyword insertion; "
            "note the triggering search term so Google's reviewer can reproduce it.")

    return {
        "auto_submit": False,
        "scope": "specific_advertisers",
        "needs_human_selection": needs_human_selection,
        "complainant": {
            "relationship": complainant.get("relationship", "authorized_agent"),
            "name": complainant.get("name", ""),
            "email": complainant.get("email", ""),
        },
        "trademark": {
            "term": brand,
            "owner": owner,
            "office": "USPTO",
            "registration_numbers": list(registration_numbers),
        },
        "countries": list(geos),
        "ads": [
            {
                "advertiser": c.advertiser,
                "trigger_query": c.trigger_query,
                "ad_text_matched": c.matched_text,
                "matched_fields": c.fields,
                "landing_url": c.landing_url,
                "final_url": c.final_url,
                "screenshot_path": c.screenshot_path,
                "geo": c.geo,
                "violation_basis": "competitive_use_of_mark_in_ad_text",
                "dki_suspected": c.dki_suspected,
            }
            for c in candidates
        ],
        "warnings": warnings,
    }


def render_markdown(pkg: dict) -> str:
    """Human-readable review doc for the draft package."""
    lines = [f"# Trademark complaint draft — {pkg['trademark']['term']}", ""]
    lines.append(f"- **Auto-submit:** {pkg['auto_submit']} (human reviews & files)")
    lines.append(f"- **Relationship:** {pkg['complainant']['relationship']}")
    lines.append(f"- **Owner:** {pkg['trademark']['owner']}")
    reg = ", ".join(pkg["trademark"]["registration_numbers"]) or "(select one)"
    lines.append(f"- **Registration #(s):** {reg}")
    lines.append(f"- **Scope:** {pkg['scope']} | **Countries:** {', '.join(pkg['countries'])}")
    if pkg["warnings"]:
        lines.append("\n## ⚠️ Before you file")
        lines += [f"- {w}" for w in pkg["warnings"]]
    lines.append(f"\n## Candidate ads ({len(pkg['ads'])})")
    for i, a in enumerate(pkg["ads"], 1):
        dki = " *(DKI-suspected)*" if a["dki_suspected"] else ""
        lines += [
            f"\n### {i}. {a['advertiser']}{dki}",
            f"- Triggering search term: `{a['trigger_query']}`",
            f"- Mark in ad text: {', '.join(a['ad_text_matched'])} "
            f"(fields: {', '.join(a['matched_fields'])})",
            f"- Landing page: {a['landing_url']}",
            f"- Screenshot: {a['screenshot_path']}",
            f"- Observed geo: {a['geo']}",
        ]
    return "\n".join(lines)
