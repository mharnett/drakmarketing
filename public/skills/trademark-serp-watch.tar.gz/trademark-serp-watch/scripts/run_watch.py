#!/usr/bin/env python3
"""trademark-serp-watch orchestrator.

Deterministic scaffolding for the skill. The landing-page read (extracting the
5 policy signals per flagged ad) is done by the model at skill-runtime — see
SKILL.md — because it is a judgment, not a rule. This CLI provides the pieces
around it.

Subcommands
-----------
  queries  BRAND                         print the brand-intent query set
  capture  BRAND --out worklist.json     capture live SERP ads + flag mark-in-copy
                                         (needs SERPAPI_KEY; network)
  finalize ASSESSED.json --out draft     classify signals, select candidates,
                                         build the reviewed draft complaint package

`finalize` input schema (produced by the model after reading each landing page):
  {
    "brand", "owner", "registration_numbers"[], "needs_human_selection",
    "complainant": {"relationship","name","email"}, "geos"[],
    "assessed": [ { "ad": <captured ad>, "match": <MarkMatch dict>,
                    "signals": <LPSignals dict>, "landing_url", "dki_suspected" } ]
  }
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.classifier import LPSignals, classify_use          # noqa: E402
from scripts.detector import MarkMatch                           # noqa: E402
from scripts.dossier import (build_draft_package, render_markdown,  # noqa: E402
                             select_candidates)
from scripts.pipeline import build_query_set, flag_ads           # noqa: E402
from scripts.serp_capture import (DEFAULT_LOCATIONS, capture_health,  # noqa: E402
                                  dedupe_ads, parse_serpapi_ads, resolve_fetch)
from scripts.uspto_lookup import (build_trademark_search_urls,  # noqa: E402
                                  open_trademark_search, fetch_justia_results,
                                  parse_justia_results, select_registrations,
                                  fetch_tsdr_status, parse_tsdr_status)

_MATCH_FIELDS = {"matched", "fields", "matched_text", "match_type", "is_own_brand"}


def _cmd_queries(args) -> int:
    for q in build_query_set(args.brand, extra_terms=args.extra):
        print(q)
    return 0


def _cmd_uspto(args) -> int:
    build = build_trademark_search_urls(args.brand, variants=args.variant)
    print("Prefilled trademark searches (Justia — indexes USPTO records; shows reg/serial #s):")
    for mark, url in zip(build["marks"], build["prefilled"]):
        print(f"  {mark}: {url}")
    print(f"Official USPTO (verify the exact live registration + class here): {build['official']}")

    if args.owner:
        _auto_prefill_registration(args.brand, args.owner)

    opened = open_trademark_search(build, do_open=not args.no_open)
    if opened:
        print(f"Opened {len(opened)} search tab(s) in your browser.")
    else:
        print("(browser not opened; omit --no-open to pop it up)")
    return 0


def _auto_prefill_registration(brand: str, owner: str) -> None:
    """Auto-select + prefill the registration ONLY on an exact owner-name match."""
    try:
        recs = parse_justia_results(fetch_justia_results(brand))
    except Exception as e:
        print(f"  (auto-prefill skipped — could not read results: {e})")
        return
    res = select_registrations(recs, brand=brand, owner=owner)
    if not res.chosen:
        print(f"  No exact owner match for '{owner}' among {len(res.exact)} "
              f"'{brand}' mark(s) — pick manually from the links above.")
        return
    c = res.chosen
    reg, status_line = c.registration_number or "", ""
    try:
        st = parse_tsdr_status(fetch_tsdr_status(c.serial_number))
        reg = st["registration_number"] or reg
        status_line = (f"    Status: {'REGISTERED' if st['registered'] else 'NOT registered'} · "
                       f"{'LIVE' if st['live'] else 'NOT live'} · {st['status_descriptor']}")
    except Exception as e:
        status_line = f"    (TSDR status unread: {e})"
    print(f"  ✓ Auto-selected on exact owner match '{owner}':")
    print(f"    Mark: {c.wordmark}   Serial: {c.serial_number}   "
          f"Registration #: {reg or '(none — see TSDR)'}")
    if status_line:
        print(status_line)


def _cmd_capture(args) -> int:
    owner_domains = args.owner_domain or []
    locations = args.geo or DEFAULT_LOCATIONS   # city-level; country returns 0 ads
    per_query: dict[str, list] = {}
    flagged: list[dict] = []
    fetch = resolve_fetch()   # hosted proxy by default; own key if SERPAPI_KEY set
    for q in build_query_set(args.brand, extra_terms=args.extra):
        collected: list = []
        for loc in locations:                # sample each city; ads are intermittent
            try:
                raw = fetch(q, geo=loc)
            except RuntimeError as e:         # quota/key issue: clean message, no traceback
                print(str(e), file=sys.stderr)
                return 2
            ads = parse_serpapi_ads(raw, trigger_query=q)
            for a in ads:
                a.geo = loc
            collected.extend(ads)
        ads = dedupe_ads(collected)
        per_query[q] = ads
        for item in flag_ads(ads, mark=args.brand, variants=args.variant,
                             owner_domains=owner_domains):
            ad = item["ad"]
            flagged.append({
                "ad": {k: getattr(ad, k) for k in
                       ("advertiser", "headlines", "descriptions", "display_url",
                        "final_url", "trigger_query", "position", "geo")},
                "match": vars(item["match"]),
                "landing_url": ad.final_url,
                "signals": {},          # to be filled by the model (LP read)
                "dki_suspected": False,  # to be set by the model
            })
    health = capture_health(per_query)
    out = {"brand": args.brand, "geo": args.geo, "capture_health": health,
           "flagged": flagged}
    _write(args.out, json.dumps(out, indent=2))
    print(f"capture_health={health['status']} flagged={len(flagged)} -> {args.out}")
    if health["warn"]:
        print("WARN:", health["warn"], file=sys.stderr)
    return 0


def _cmd_finalize(args) -> int:
    data = json.loads(_read(args.infile))
    assessed = []
    for item in data.get("assessed", []):
        md = {k: v for k, v in item["match"].items() if k in _MATCH_FIELDS}
        match = MarkMatch(**md)
        bucket = classify_use(LPSignals(**item.get("signals", {})))
        assessed.append({
            "ad": item["ad"], "match": match, "bucket": bucket,
            "landing_url": item.get("landing_url"),
            "dki_suspected": item.get("dki_suspected", False),
        })
    candidates = select_candidates(assessed)
    pkg = build_draft_package(
        brand=data["brand"], owner=data.get("owner", ""),
        registration_numbers=data.get("registration_numbers", []),
        needs_human_selection=data.get("needs_human_selection", True),
        candidates=candidates,
        complainant=data.get("complainant", {}),
        geos=data.get("geos", []),
    )
    _write(args.out, json.dumps(pkg, indent=2))
    md_path = os.path.splitext(args.out)[0] + ".md"
    _write(md_path, render_markdown(pkg))
    print(f"candidates={len(pkg['ads'])} -> {args.out} + {md_path}")
    for w in pkg["warnings"]:
        print("WARN:", w, file=sys.stderr)
    return 0


def _read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def _write(path: str, content: str) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)


def main(argv=None) -> int:
    p = argparse.ArgumentParser(description="trademark-serp-watch orchestrator")
    sub = p.add_subparsers(dest="cmd", required=True)

    q = sub.add_parser("queries")
    q.add_argument("brand")
    q.add_argument("--extra", nargs="*", default=None)
    q.set_defaults(func=_cmd_queries)

    us = sub.add_parser("uspto")
    us.add_argument("brand")
    us.add_argument("--variant", action="append", default=None,
                    help="Family variant / product name to also search (repeatable).")
    us.add_argument("--owner", default=None,
                    help="Trademark owner / company name. On an EXACT owner match, "
                         "auto-selects and prefills that registration number.")
    us.add_argument("--no-open", action="store_true",
                    help="Print the prefilled links without opening the browser.")
    us.set_defaults(func=_cmd_uspto)

    c = sub.add_parser("capture")
    c.add_argument("brand")
    c.add_argument("--geo", action="append", default=None,
                   help="City-level location, e.g. 'Austin, Texas, United States' "
                        "(repeatable). Country-level returns 0 ads. Default: 3 US cities.")
    c.add_argument("--owner-domain", action="append", default=None)
    c.add_argument("--variant", action="append", default=None,
                   help="Additional mark in the same family to detect in ad copy, "
                        "e.g. a product name like 'Neon CRM' (repeatable).")
    c.add_argument("--extra", nargs="*", default=None)
    c.add_argument("--out", required=True)
    c.set_defaults(func=_cmd_capture)

    f = sub.add_parser("finalize")
    f.add_argument("infile")
    f.add_argument("--out", required=True)
    f.set_defaults(func=_cmd_finalize)

    args = p.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
