"""Brand-mark-in-ad-text detector.

Decides whether a trademark appears in an ad's *visible copy* (headlines,
descriptions, display URL). This is a text question only — NOT an infringement
judgment. Because the SERP capture stores the ad as *served*, this also catches
dynamic-keyword-insertion (DKI) renders that put the mark in the copy at auction
time; the classifier decides whether any match is actually a policy violation.

Design choices:
  - Multi-token marks match their tokens separated only by optional
    whitespace/punctuation, anchored on word boundaries. So "Neon One" matches
    "neon one", "NeonOne", "Neon-One" but NOT "neon signs ... one-time" (tokens
    not adjacent) nor "Neon Oneness" (no trailing boundary).
  - An exact (case-insensitive, same separators) hit is `match_type="exact"`;
    a different-separator or caller-supplied-variant hit is `"variant"`.
  - Owner-own ads are flagged (`is_own_brand`) so downstream candidate
    selection can drop them — they contain the mark legitimately.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

# Fields whose text is visible to the user and therefore "ad copy".
_TEXT_FIELDS = ("headlines", "descriptions", "display_url")
# Characters allowed *between* the tokens of a multi-token mark.
_SEP = r"[\s\-_.]*"


@dataclass
class MarkMatch:
    matched: bool
    fields: list[str] = field(default_factory=list)
    matched_text: list[str] = field(default_factory=list)
    match_type: str = "none"          # "exact" | "variant" | "none"
    is_own_brand: bool = False


def _mark_regex(mark: str) -> re.Pattern:
    tokens = [re.escape(t) for t in mark.split()]
    body = _SEP.join(tokens)
    return re.compile(rf"(?<![0-9A-Za-z]){body}(?![0-9A-Za-z])", re.IGNORECASE)


def _variant_regexes(variants: list[str]) -> list[re.Pattern]:
    out = []
    for v in variants:
        out.append(re.compile(
            rf"(?<![0-9A-Za-z]){re.escape(v)}(?![0-9A-Za-z])", re.IGNORECASE))
    return out


def _field_values(ad: dict, name: str) -> list[str]:
    val = ad.get(name)
    if val is None:
        return []
    return list(val) if isinstance(val, (list, tuple)) else [str(val)]


def _is_own_brand(ad: dict, owner_domains: list[str]) -> bool:
    if not owner_domains:
        return False
    owners = [d.lower().lstrip(".") for d in owner_domains]
    haystacks = []
    for key in ("final_url", "display_url"):
        raw = (ad.get(key) or "")
        host = urlparse(raw if "//" in raw else "//" + raw).hostname or raw
        haystacks.append(host.lower())
    for host in haystacks:
        for owner in owners:
            if host == owner or host.endswith("." + owner):
                return True
    return False


def find_mark_in_ad(ad: dict, mark: str, variants: list[str] | None = None,
                    owner_domains: list[str] | None = None) -> MarkMatch:
    """Return a MarkMatch describing whether `mark` appears in the ad copy."""
    exact_re = _mark_regex(mark)
    variant_res = _variant_regexes(variants or [])
    mark_norm = mark.lower()

    hit_fields: list[str] = []
    hit_text: list[str] = []
    saw_exact = False
    saw_variant = False

    for fname in _TEXT_FIELDS:
        field_matched = False
        for value in _field_values(ad, fname):
            for m in exact_re.finditer(value):
                text = m.group(0)
                field_matched = True
                hit_text.append(text)
                # "exact" = same normalized text as the mark (case-insensitive);
                # any other separator arrangement is a "variant".
                if text.lower() == mark_norm:
                    saw_exact = True
                else:
                    saw_variant = True
            for vre in variant_res:
                for m in vre.finditer(value):
                    field_matched = True
                    saw_variant = True
                    hit_text.append(m.group(0))
        if field_matched:
            hit_fields.append(fname)

    if saw_exact:
        match_type = "exact"
    elif saw_variant:
        match_type = "variant"
    else:
        match_type = "none"

    return MarkMatch(
        matched=bool(hit_fields),
        fields=hit_fields,
        matched_text=list(dict.fromkeys(hit_text)),   # dedupe, keep order
        match_type=match_type,
        is_own_brand=_is_own_brand(ad, owner_domains or []),
    )
