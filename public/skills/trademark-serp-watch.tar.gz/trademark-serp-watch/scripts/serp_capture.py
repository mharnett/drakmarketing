"""Provider-agnostic SERP capture.

Live SERP capture is the only way to catch a mark inserted via dynamic keyword
insertion (DKI) AND to produce the per-query screenshot Google's complaint form
requires — the Ads Transparency Center can do neither. This module normalizes a
provider response into CapturedAd rows and reports capture health.

Reference provider: SerpAPI. Add another provider by writing a `parse_*_ads`
function that returns `list[CapturedAd]` and a `fetch` that returns raw JSON.
Bring-your-own API key: a single-brand watch (~10-15 queries/run) fits SerpAPI's
free tier, so syndicated users pay nothing and the operator subsidizes no calls.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from urllib.parse import urlparse


@dataclass
class CapturedAd:
    advertiser: str
    headlines: list[str]
    descriptions: list[str]
    display_url: str
    final_url: str
    trigger_query: str
    position: str = ""          # "top" | "bottom" | ""
    observed_at: str = ""       # caller stamps (kept out of pure logic)
    geo: str = ""
    screenshot_path: str = ""
    raw: dict = field(default_factory=dict)


# Google ad auctions only trigger at CITY granularity — a bare country like
# "United States" returns zero ads. Sampling a few large cities also mitigates
# the auction/time non-determinism (an ad may serve in one city but not another).
DEFAULT_LOCATIONS = [
    "New York, New York, United States",
    "Austin, Texas, United States",
    "Chicago, Illinois, United States",
]


def dedupe_ads(ads: list) -> list:
    """Collapse the same ad observed across multiple cities/queries.

    Identity = (advertiser, final_url, headlines). Distinct creatives from the
    same advertiser are kept. First occurrence wins (retains its geo/trigger).
    """
    seen = set()
    out = []
    for a in ads:
        key = (a.advertiser, a.final_url, tuple(a.headlines))
        if key in seen:
            continue
        seen.add(key)
        out.append(a)
    return out


def _advertiser(entry: dict) -> str:
    src = (entry.get("source") or "").strip()
    if src:
        return src
    disp = entry.get("displayed_link") or entry.get("link") or ""
    host = urlparse(disp if "//" in disp else "//" + disp).hostname or disp
    return host.replace("www.", "")


def parse_serpapi_ads(raw: dict, trigger_query: str) -> list[CapturedAd]:
    """Map a SerpAPI Google Search response into normalized CapturedAd rows."""
    out: list[CapturedAd] = []
    for entry in raw.get("ads", []) or []:
        title = entry.get("title") or ""
        desc = entry.get("description") or entry.get("snippet") or ""
        out.append(CapturedAd(
            advertiser=_advertiser(entry),
            headlines=[title] if title else [],
            descriptions=[desc] if desc else [],
            display_url=entry.get("displayed_link") or "",
            final_url=entry.get("link") or "",
            trigger_query=trigger_query,
            position=entry.get("block_position") or "",
            raw=entry,
        ))
    return out


def capture_health(per_query_results: dict[str, list]) -> dict:
    """Summarize a run. Total-zero is 'suspect', never reported as clean.

    Zero ads across every query is indistinguishable from a failed capture
    (throttled key, CAPTCHA, schema drift), so it must not be interpreted as
    'no infringement found'.
    """
    total = sum(len(v) for v in per_query_results.values())
    with_ads = sum(1 for v in per_query_results.values() if v)
    q_total = len(per_query_results)
    if total == 0:
        return {
            "status": "suspect_zero",
            "total_ads": 0,
            "queries_with_ads": 0,
            "queries_total": q_total,
            "warn": ("0 ads across all queries — capture likely failed "
                     "(throttled key / CAPTCHA / schema change). Do NOT read "
                     "this as 'no infringement'."),
        }
    return {
        "status": "ok",
        "total_ads": total,
        "queries_with_ads": with_ads,
        "queries_total": q_total,
        "warn": "",
    }


def require_serpapi_key(api_key: str | None = None, env: dict | None = None) -> str:
    """Resolve the SerpAPI key or raise an actionable, BYO-key setup error.

    The skill never ships or shares a key — each user brings their own (free tier
    = 250 searches/month, ~35 default runs). A wrong assumption here (piggybacking
    on someone else's key) would both drain their quota and leak a credential.
    """
    if api_key:
        return api_key
    env = os.environ if env is None else env
    key = env.get("SERPAPI_KEY")
    if key:
        return key
    raise RuntimeError(
        "SERPAPI_KEY not set. This skill uses YOUR OWN SerpAPI key — it never "
        "ships or shares one. The free tier (250 searches/month, ~35 default "
        "runs) covers a single-brand watch.\n"
        "  1. Get a key: https://serpapi.com/manage-api-key\n"
        "  2. Set it:    export SERPAPI_KEY=your_key\n"
        "  (or pass api_key=... , or plug in another provider — see SKILL.md)."
    )


# Hosted proxy default: downloaded skills call the operator's key-holding relay,
# so end users need no SerpAPI key. Override per-user with SERPWATCH_PROXY_URL.
# Update this to the deployed proxy URL (see services/trademark-serp-proxy).
DEFAULT_PROXY_URL = "https://drak-stack-monorepo-production.up.railway.app/serp"


def proxy_url(env: dict | None = None) -> str:
    env = os.environ if env is None else env
    return env.get("SERPWATCH_PROXY_URL") or DEFAULT_PROXY_URL


def resolve_fetch(env: dict | None = None):
    """Pick the capture function: BYO key if present, else the hosted proxy.

    A user who sets their own SERPAPI_KEY spends their own quota (and costs the
    operator nothing); everyone else transparently uses the hosted, tip-funded
    relay with no key or setup.
    """
    env = os.environ if env is None else env
    return fetch_serpapi if env.get("SERPAPI_KEY") else fetch_proxy


def fetch_proxy(query: str, geo: str = DEFAULT_LOCATIONS[0],
                url: str | None = None) -> dict:
    """Call the hosted proxy; returns SerpAPI-shaped JSON (parse unchanged)."""
    import requests  # local import: keep module importable without the dep

    resp = requests.post(url or proxy_url(), json={"query": query, "geo": geo},
                         timeout=30)
    if resp.status_code == 429:
        raise RuntimeError(
            "The free, tip-funded search quota is busy or used up for now — "
            "try again later, or set your own SERPAPI_KEY to run unthrottled.")
    resp.raise_for_status()
    return resp.json()


# --- HTTP seam (not exercised in CI) --------------------------------------

def fetch_serpapi(query: str, geo: str = DEFAULT_LOCATIONS[0], api_key: str | None = None) -> dict:
    """Live SerpAPI call. Returns raw JSON. Requires a bring-your-own key.

    Kept thin and separate from parsing so tests never hit the network.
    """
    import requests  # local import: keep module importable without the dep

    key = require_serpapi_key(api_key)
    resp = requests.get(
        "https://serpapi.com/search.json",
        params={"engine": "google", "q": query, "location": geo,
                "google_domain": "google.com", "gl": "us", "hl": "en",
                "api_key": key},
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()
