"""Landing-page use classifier — the false-positive guard.

Maps landing-page signals to a Google Ads trademark-policy bucket and decides
whether the ad is a complaint candidate. The signals themselves are extracted
from the live landing page by the skill's model at runtime (see SKILL.md); this
module is the deterministic, testable decision layer.

Policy basis: references/google-tm-policy.md. The decision order and the
conservative "mixed signals -> AMBIGUOUS" rule exist so that a permitted use
(reseller / informational / partner) is NEVER auto-filed as a complaint. Only an
unambiguous COMPETITIVE use becomes a candidate.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class Bucket(Enum):
    OWN_BRAND = "own_brand"
    PARTNER_AFFILIATE = "partner_affiliate"
    RESELLER = "reseller"
    INFORMATIONAL = "informational"
    COMPETITIVE = "competitive"
    AMBIGUOUS = "ambiguous"


@dataclass(frozen=True)
class LPSignals:
    """Boolean primary-purpose signals read from the landing page."""
    advertiser_is_owner: bool = False
    states_partner_affiliation: bool = False
    sells_marked_product: bool = False
    is_review_or_info_primary: bool = False
    promotes_own_competing_product: bool = False


def classify_use(s: LPSignals) -> Bucket:
    """Return the policy bucket for a landing page. First match wins."""
    if s.advertiser_is_owner:
        return Bucket.OWN_BRAND
    if s.states_partner_affiliation:
        return Bucket.PARTNER_AFFILIATE
    if s.sells_marked_product and not s.promotes_own_competing_product:
        return Bucket.RESELLER
    if s.is_review_or_info_primary and not s.promotes_own_competing_product:
        return Bucket.INFORMATIONAL
    # Competitive use requires an own-product push AND no permitted-use signal.
    if s.promotes_own_competing_product and not (
        s.sells_marked_product
        or s.is_review_or_info_primary
        or s.states_partner_affiliation
    ):
        return Bucket.COMPETITIVE
    return Bucket.AMBIGUOUS


def is_complaint_candidate(bucket: Bucket) -> bool:
    """Only an unambiguous competitive use is an auto-included candidate."""
    return bucket is Bucket.COMPETITIVE
