"""Query-set generation + capture->detect flagging.

Deterministic scaffolding around the model-driven landing-page read. The CLI
uses `build_query_set` to decide what to capture and `flag_ads` to reduce a
capture to the ads whose copy actually contains the mark (excluding the owner's
own ads). The flagged ads are what the model then classifies by reading each
landing page.
"""
from __future__ import annotations

from dataclasses import asdict, is_dataclass

from scripts.detector import find_mark_in_ad

# Brand-intent query templates. Kept small so a single-brand watch fits a SERP
# provider's free tier.
_INTENT_TEMPLATES = [
    "{b}",
    "{b} reviews",
    "{b} alternative",
    "{b} pricing",
    "{b} vs",
    "{b} login",
    "{b} competitors",
]


def build_query_set(brand: str, extra_terms: list[str] | None = None) -> list[str]:
    """Generate brand-intent search queries, deduped, order-preserving."""
    queries = [t.format(b=brand) for t in _INTENT_TEMPLATES]
    if extra_terms:
        queries += list(extra_terms)
    return list(dict.fromkeys(queries))


def _as_dict(ad) -> dict:
    if is_dataclass(ad) and not isinstance(ad, type):
        return asdict(ad)
    return dict(ad)


def flag_ads(captured_ads, mark: str, variants: list[str] | None = None,
             owner_domains: list[str] | None = None) -> list[dict]:
    """Return worklist items {ad, match} for ads with the mark in their copy.

    Owner-own ads are dropped here (they contain the mark legitimately). Each
    kept item still needs a landing-page classification before it can become a
    complaint candidate.
    """
    worklist: list[dict] = []
    for ad in captured_ads:
        ad_d = _as_dict(ad)
        match = find_mark_in_ad(ad_d, mark=mark, variants=variants,
                                owner_domains=owner_domains)
        if match.matched and not match.is_own_brand:
            worklist.append({"ad": ad, "match": match})
    return worklist
