# Google Ads trademark complaint — form field map

The draft package (`dossier.py`) pre-fills these fields so a human only has to
review and submit. **This skill never auto-submits** — Google's form is behind a
Google login and requires a human authorization-verification loop.

Google's current form (routes from
https://support.google.com/adspolicy/troubleshooter/1114905 →
"Trademark owners" → "Report ads that may be violating trademark policy").

## Page 1 — Complainant

| Field | Where it comes from |
|---|---|
| Your relationship to the trademark | `Trademark owner` OR `Authorized to act on behalf of the owner` (agency). Set per engagement; defaults to agency for syndicated use. |
| Your name / company | The submitting party. |
| Contact email | Must be reachable — Google emails here to run the authorization verification. |
| Trademark owner name | From USPTO lookup (`registrant`). |

## Page 2 — The trademark

| Field | Where it comes from |
|---|---|
| Trademarked term | The wordmark. |
| Trademark registration number | From USPTO lookup — the **human-selected** live registration (never auto-picked when multiple exist). |
| Trademark office | USPTO (or local office). |
| Registration jurisdiction / class | From USPTO lookup; confirm the class covers the goods/services at issue. |

## Page 3 — Scope

| Field | Value |
|---|---|
| Scope | `Only specific advertisers` (list them) — never "all advertisers" from an automated run. |
| Countries affected | The geos where the ad was observed. |

## Page 4 — Per-ad evidence (one block per candidate)

For EACH complaint candidate, the dossier provides:

| Field | Source |
|---|---|
| The ad's triggering search term(s) | `ad.trigger_query` |
| The ad text showing the mark | headline/description with the matched span highlighted |
| Screenshot of the ad as served | `ad.screenshot_path` (live SERP capture — required; the Transparency Center cannot provide this for DKI) |
| Advertiser (display name / final URL) | `ad.advertiser`, `ad.final_url` |
| Landing-page URL + why it violates | `candidate.landing_url` + `classifier` rationale (bucket = COMPETITIVE) |
| Date/time + geo observed | `ad.observed_at`, `ad.geo` |

## DKI-flagged candidates

If a candidate's mark appears only via **dynamic keyword insertion** (the
advertiser's stored creative shows different default text), the dossier labels it
`DKI-suspected`. The evidentiary bar is higher — the human should note in the
complaint that the term is served via keyword insertion for the given query, so
Google's reviewer reproduces it with the same search term rather than inspecting
the (clean-looking) stored creative.
