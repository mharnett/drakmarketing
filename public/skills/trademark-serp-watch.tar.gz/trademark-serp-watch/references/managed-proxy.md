# Follow-on sketch: managed proxy (monetize without exposing a key)

**Status: design sketch, not built.** The shipped skill is BYO-key. This is the
option for when you want users to NOT need their own SerpAPI key — i.e. you sell
access and hold the key server-side.

## The core idea

Don't embed your key in the skill (a distributed artifact = a leaked key). Put a
thin authenticated relay in front of SerpAPI. The skill calls *your* endpoint
with a per-user license token; your server adds the SerpAPI key and forwards.

```
  skill (fetch_proxy)  --Bearer <user license token>-->  YOUR PROXY  --SERPAPI_KEY-->  SerpAPI
        |                                                     |                            |
        |<---------------- SerpAPI-shaped JSON ---------------|<-- raw JSON ---------------|
```

## Why it's a small build

The proxy returns the **same SerpAPI-shaped JSON**, so `parse_serpapi_ads` and
the entire downstream pipeline are unchanged. Only the fetch changes:

```python
# scripts/serp_capture.py — additive, coexists with BYO-key
def fetch_proxy(query, geo="United States", *, proxy_url=None, token=None):
    import requests
    proxy_url = proxy_url or os.environ["SERPWATCH_PROXY_URL"]
    token = token or os.environ["SERPWATCH_TOKEN"]
    r = requests.post(proxy_url, json={"query": query, "geo": geo},
                      headers={"Authorization": f"Bearer {token}"}, timeout=30)
    if r.status_code == 401: raise RuntimeError("Invalid or expired license token.")
    if r.status_code == 429: raise RuntimeError("Monthly quota exceeded for your plan.")
    r.raise_for_status()
    return r.json()          # SerpAPI-shaped passthrough → parse_serpapi_ads unchanged
```

Selection rule in the CLI: if `SERPWATCH_PROXY_URL`+`SERPWATCH_TOKEN` are set,
use `fetch_proxy`; else fall back to BYO `fetch_serpapi`. Both models live side by
side — power users BYO, paying users use your token.

## Endpoint contract (minimum)

`POST /serp`  ·  `Authorization: Bearer <token>`  ·  body `{"query": str, "geo": str}`

| Response | Meaning |
|---|---|
| `200` + SerpAPI JSON | success; usage decremented for that token |
| `401` | missing/invalid/expired token |
| `429` | token's monthly quota exhausted |
| `400` | query failed input validation (see abuse guardrails) |

## Auth & quota (per-user, not pooled)

The failure mode of a shared key is that it's **pooled** — one heavy user starves
everyone. The proxy fixes that by metering **per token**:

- Each paying user gets a token mapped to a plan (e.g. Starter = 200 runs/mo).
- The server tracks usage per token and returns `429` at the cap — one user can
  never drain another's allotment or your upstream bill.
- Start tokenless-DB-free with **signed JWTs** (plan + expiry in the claim); add a
  usage store (Redis/Postgres row per token-month) when you need hard quotas.

## Security (this is a credential-holding, billable relay — treat it as one)

- **SerpAPI key lives only in the proxy's server env.** Never in the skill,
  never in logs (build-log threat model — don't print the forwarded request).
  Rotate it anytime without touching a single user.
- **Validate input — it's a paid relay to a metered upstream.** Accept only the
  brand-watch query shape, cap queries per request, reject anything else, so the
  endpoint can't be turned into a general-purpose SerpAPI-on-your-dime or an SSRF
  vector. Log usage per token.
- **Rate-limit** per token AND per IP as a backstop against token theft.

## Cost / pricing math

Wholesale SerpAPI ≈ $25 / 1,000 searches ($0.025/search at entry; cheaper
providers ~$0.001–0.002). A default run = 7 searches, so 1,000 searches ≈ **~140
runs**. Price a plan above your blended cost:

- Starter: 200 runs/mo → ~1,400 searches → ~$35 upstream on SerpAPI (less on a
  cheaper provider) → price with margin.
- Because the pipeline is provider-agnostic, swap in a $0.001/search provider
  and your cost per run drops ~20× while the skill code is untouched.

## Deployment

Fits your existing Railway pattern: one small service, `SERPAPI_KEY` +
`JWT_SIGNING_SECRET` (or a token table) in service env, Stripe webhook issues
tokens on payment. **Run the Devil's-Advocate + Pre-Mortem gates before building
it** — it introduces a credential-holding, money-touching endpoint, which is
exactly the security-sensitive-primitive class those gates exist for.
