# Google Ads trademark policy — the rules the classifier encodes

Source of truth: Google Ads "Trademarks" policy
(https://support.google.com/adspolicy/answer/6118). Summarized here so the
`classify_use()` decision function has an auditable basis. When Google changes
the policy, update BOTH this file and the anchor tests in
`tests/test_classifier.py`.

## The one thing to internalize

**Bidding on a competitor's trademarked KEYWORD is allowed. Using the
trademark in the AD TEXT is restricted — but with broad exceptions.** A
competitor's brand appearing in ad copy is therefore *not, by itself,
infringement*. Whether it violates policy depends almost entirely on the
**landing page**.

This is why the pipeline never files on a string match alone. The string match
(`detector.py`) only decides "the mark is in the copy." The landing-page read
(`classifier.py`) decides "is this a policy violation."

## Permitted uses of a mark in ad text (NOT complaint candidates)

Google permits the trademark term in ad text when the ad + landing page make the
advertiser's role clear and the page's primary purpose is one of:

| Bucket | Condition | Signal we extract |
|---|---|---|
| `RESELLER` | LP is primarily dedicated to **selling the marked product/service**, and shows commercial info (price/rate). | `sells_marked_product` |
| `INFORMATIONAL` | LP's primary purpose is to provide **informative detail / reviews about the marked product** (neutral third-party review, comparison, news). | `is_review_or_info_primary` |
| `PARTNER_AFFILIATE` | LP indicates the advertiser is an authorized **partner, channel partner, or affiliate**. | `states_partner_affiliation` |

If the LP requires the user to hand over extensive info before showing any
commercial content, the reseller/informational defense fails — but we treat that
as `AMBIGUOUS` (manual review), not an automatic violation, to stay conservative.

## Prohibited use (the ONLY complaint candidate)

| Bucket | Condition | Signal we extract |
|---|---|---|
| `COMPETITIVE` | The mark is used to divert the user to a **competing product** — the LP's primary push is the advertiser's own rival product, and NONE of the permitted-use signals are present. | `promotes_own_competing_product` |

## Conservative-by-design decision order

`classify_use()` applies these in order and stops at the first match:

1. `advertiser_is_owner` → `OWN_BRAND` (the mark owner's own ad — never a violation)
2. `states_partner_affiliation` → `PARTNER_AFFILIATE`
3. `sells_marked_product` AND NOT `promotes_own_competing_product` → `RESELLER`
4. `is_review_or_info_primary` AND NOT `promotes_own_competing_product` → `INFORMATIONAL`
5. `promotes_own_competing_product` AND NO permitted-use signal → `COMPETITIVE`
6. otherwise → `AMBIGUOUS`

**Only `COMPETITIVE` is an auto-included complaint candidate.** Mixed signals
(e.g. a page that both sells the marked product AND pushes a rival) resolve to
`AMBIGUOUS` → routed to human review, never auto-filed. This asymmetry is
deliberate: a wrongful filing under the client's legal identity is far more
costly than a missed one that a human can still catch in the review queue.

## Who may file

The complaint is a **legal attestation of good-faith belief**, filed by the
trademark owner or an **authorized agent**. An agency can submit, but Google then
emails the agency and requires the trademark owner to reply confirming
authorization. There is no fully-automated path — a human at the owner always
closes the loop. This is why this skill stops at a reviewed draft package.
