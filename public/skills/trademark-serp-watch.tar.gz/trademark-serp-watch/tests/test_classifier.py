"""Anchor + shape tests for the landing-page use classifier.

`classify_use()` is the false-positive guard: it maps landing-page signals to a
Google-policy bucket and only ever lets a `COMPETITIVE` use become a complaint
candidate. Mixed / unclear signals resolve to `AMBIGUOUS` (human review), never
to an auto-filed complaint. The invariant that must NEVER break: a permitted-use
page (reseller / informational / partner) is never a candidate.

Signals are extracted from the live landing page by the skill's model at
runtime; this module tests only the deterministic signals -> bucket decision.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.classifier import (  # noqa: E402
    Bucket, LPSignals, classify_use, is_complaint_candidate,
)


def sig(**kw) -> LPSignals:
    return LPSignals(**kw)


# --- anchors: category -> bucket regardless of the other dimensions -------

def test_competing_product_no_legit_signal_is_competitive_and_candidate():
    s = sig(promotes_own_competing_product=True)
    assert classify_use(s) is Bucket.COMPETITIVE
    assert is_complaint_candidate(classify_use(s)) is True


def test_reseller_selling_marked_product_is_reseller_not_candidate():
    s = sig(sells_marked_product=True)
    assert classify_use(s) is Bucket.RESELLER
    assert is_complaint_candidate(classify_use(s)) is False


def test_informational_review_page_is_informational_not_candidate():
    s = sig(is_review_or_info_primary=True)
    assert classify_use(s) is Bucket.INFORMATIONAL
    assert is_complaint_candidate(classify_use(s)) is False


def test_partner_affiliation_is_partner_even_if_it_also_competes():
    # Partner/affiliate status is a full defense and wins over everything else.
    s = sig(states_partner_affiliation=True, promotes_own_competing_product=True)
    assert classify_use(s) is Bucket.PARTNER_AFFILIATE
    assert is_complaint_candidate(classify_use(s)) is False


def test_owner_own_ad_is_own_brand_regardless():
    s = sig(advertiser_is_owner=True, promotes_own_competing_product=True)
    assert classify_use(s) is Bucket.OWN_BRAND
    assert is_complaint_candidate(classify_use(s)) is False


# --- conservative mixed-signal handling (the core safety property) --------

def test_competes_but_also_sells_marked_product_is_ambiguous_not_candidate():
    # A page that both pushes a rival AND sells the marked product is unclear.
    # Must go to manual review, never auto-file.
    s = sig(promotes_own_competing_product=True, sells_marked_product=True)
    assert classify_use(s) is Bucket.AMBIGUOUS
    assert is_complaint_candidate(classify_use(s)) is False


def test_competes_but_also_informational_is_ambiguous():
    s = sig(promotes_own_competing_product=True, is_review_or_info_primary=True)
    assert classify_use(s) is Bucket.AMBIGUOUS
    assert is_complaint_candidate(classify_use(s)) is False


def test_no_signals_is_ambiguous_not_candidate():
    assert classify_use(sig()) is Bucket.AMBIGUOUS
    assert is_complaint_candidate(classify_use(sig())) is False


def test_reseller_beats_informational_by_priority():
    s = sig(sells_marked_product=True, is_review_or_info_primary=True)
    assert classify_use(s) is Bucket.RESELLER


# --- shape / invariant across a representative golden batch ----------------

# (signals, expected_bucket)
GOLDEN = [
    (sig(promotes_own_competing_product=True), Bucket.COMPETITIVE),
    (sig(sells_marked_product=True), Bucket.RESELLER),
    (sig(is_review_or_info_primary=True), Bucket.INFORMATIONAL),
    (sig(states_partner_affiliation=True), Bucket.PARTNER_AFFILIATE),
    (sig(advertiser_is_owner=True), Bucket.OWN_BRAND),
    (sig(promotes_own_competing_product=True, sells_marked_product=True), Bucket.AMBIGUOUS),
    (sig(), Bucket.AMBIGUOUS),
    (sig(promotes_own_competing_product=True, is_review_or_info_primary=True), Bucket.AMBIGUOUS),
]


def test_golden_bucket_distribution():
    got = {}
    for s, _ in GOLDEN:
        b = classify_use(s)
        got[b] = got.get(b, 0) + 1
    assert got == {
        Bucket.COMPETITIVE: 1,
        Bucket.RESELLER: 1,
        Bucket.INFORMATIONAL: 1,
        Bucket.PARTNER_AFFILIATE: 1,
        Bucket.OWN_BRAND: 1,
        Bucket.AMBIGUOUS: 3,
    }


def test_invariant_permitted_use_is_never_a_candidate():
    for s, _ in GOLDEN:
        bucket = classify_use(s)
        if is_complaint_candidate(bucket):
            # every candidate must be a true competitive use with no legit signal
            assert bucket is Bucket.COMPETITIVE
            assert s.promotes_own_competing_product is True
            assert s.sells_marked_product is False
            assert s.is_review_or_info_primary is False
            assert s.states_partner_affiliation is False
            assert s.advertiser_is_owner is False


def test_golden_matches_expected_labels():
    for s, expected in GOLDEN:
        assert classify_use(s) is expected
