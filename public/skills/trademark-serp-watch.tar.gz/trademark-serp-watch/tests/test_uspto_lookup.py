"""Contract tests for the USPTO trademark lookup adapter.

The HTTP call is a seam; the tested logic is (a) normalizing status to a live
flag and (b) selecting registrations — which must NEVER auto-pick a single
registration when zero or several live marks match. A wrong reg number invalidates
the whole complaint, so ambiguity always routes to a human (pre-mortem #4).
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.uspto_lookup import (  # noqa: E402
    TrademarkRecord, parse_tsdr_records, select_registrations,
    justia_search_url, build_trademark_search_urls, open_trademark_search,
    USPTO_OFFICIAL_SEARCH, parse_justia_results, parse_tsdr_status,
)

# Real captured Justia results text (trimmed) — three "NEON ONE"-ish hits with
# three DIFFERENT owners. Only one is the client's company.
JUSTIA_RESULTS = """Trademark Search Results

Results 1 - 20 of 500

NEON ONE

Filed: April 15, 2020
STATISTICAL EVALUATION OF MARKETING DATA; MARKET ANALYSIS
Owned by: INTERNATIONAL DATA GROUP, INC.
Serial Number: 88873076

NEON ONE

Filed: December 2, 2025
Providing online non-downloadable software for use by nonprofit organizations
Owned by: Neon One, LLC
Serial Number: 99525183

MULTINEON COLORCHANGER

Filed: March 22, 1999
Electrical controllable power supply for controlling one or more neon lights
Owned by: LOWEL-LIGHT MANUFACTURING, INC.
Serial Number: 75665547
"""

# Real captured TSDR status text (trimmed) for serial 99525183.
TSDR_TEXT = """Register:
Principal
Mark Type:
Service Mark
TM5 Common Status Descriptor:

LIVE/REGISTRATION/Issued and Active

The trademark application has been registered with the Office.

Status:
Registered. The registration date is used to determine maintenance.
Status Date:
Jun. 30, 2026
US Registration Number:
8322586
Mark Literal Elements:
NEON ONE
"""

RAW = {
    "trademarks": [
        {"wordmark": "NEON ONE", "registrationNumber": "6123456",
         "serialNumber": "88123456", "status": "REGISTERED",
         "owner": "Neon One, LLC", "internationalClass": "042"},
        {"wordmark": "NEON ONE", "registrationNumber": "5000001",
         "serialNumber": "87000001", "status": "CANCELLED",
         "owner": "Old Holder Inc", "internationalClass": "009"},
        {"wordmark": "NEON ONE PAY", "registrationNumber": "6222222",
         "serialNumber": "88222222", "status": "LIVE",
         "owner": "Neon One, LLC", "internationalClass": "036"},
    ]
}


def test_parse_normalizes_live_flag():
    recs = parse_tsdr_records(RAW)
    by_reg = {r.registration_number: r for r in recs}
    assert by_reg["6123456"].live is True     # REGISTERED -> live
    assert by_reg["5000001"].live is False    # CANCELLED  -> dead
    assert by_reg["6222222"].live is True     # LIVE       -> live


def test_select_drops_dead_and_flags_single_exact_live():
    recs = parse_tsdr_records(RAW)
    result = select_registrations(recs, brand="Neon One")
    # only one LIVE mark whose wordmark exactly equals the brand
    assert [r.registration_number for r in result.exact] == ["6123456"]
    assert all(r.live for r in result.all_live)
    assert "5000001" not in [r.registration_number for r in result.all_live]
    # exactly one live exact match -> a human still confirms, but not ambiguous
    assert result.needs_human_selection is False


def test_multiple_live_exact_marks_require_human_selection():
    recs = [
        TrademarkRecord("NEON ONE", "6123456", "88123456", "REGISTERED",
                        "Neon One, LLC", "042", True),
        TrademarkRecord("NEON ONE", "6987654", "88987654", "REGISTERED",
                        "Neon One, LLC", "009", True),
    ]
    result = select_registrations(recs, brand="Neon One")
    assert len(result.exact) == 2
    assert result.needs_human_selection is True


def test_no_exact_live_match_requires_human_selection():
    recs = [
        TrademarkRecord("NEON ONE PAY", "6222222", "88222222", "LIVE",
                        "Neon One, LLC", "036", True),
    ]
    result = select_registrations(recs, brand="Neon One")
    assert result.exact == []
    assert result.needs_human_selection is True


# --- prefilled trademark search links + browser pop-up --------------------

def test_justia_search_url_encodes_the_mark():
    assert justia_search_url("Neon One") == \
        "https://trademarks.justia.com/search?q=Neon+One"


def test_build_search_urls_covers_brand_and_variants_plus_official():
    build = build_trademark_search_urls("Neon One", variants=["Neon CRM"])
    assert justia_search_url("Neon One") in build["prefilled"]
    assert justia_search_url("Neon CRM") in build["prefilled"]
    assert build["official"] == USPTO_OFFICIAL_SEARCH
    assert "uspto.gov" in build["official"]


def test_open_trademark_search_pops_each_prefilled_url():
    opened = []
    build = build_trademark_search_urls("Neon One", variants=["Neon CRM"])
    open_trademark_search(build, opener=opened.append)
    assert opened == build["prefilled"]      # opened every prefilled search, in order


def test_open_trademark_search_respects_no_open():
    opened = []
    build = build_trademark_search_urls("Neon One")
    open_trademark_search(build, opener=opened.append, do_open=False)
    assert opened == []


# --- parse Justia results into attributed records -------------------------

def test_parse_justia_extracts_mark_owner_serial_per_hit():
    recs = parse_justia_results(JUSTIA_RESULTS)
    by_serial = {r.serial_number: r for r in recs}
    assert by_serial["88873076"].wordmark == "NEON ONE"
    assert by_serial["88873076"].owner.startswith("INTERNATIONAL DATA GROUP")
    assert by_serial["99525183"].wordmark == "NEON ONE"
    assert by_serial["99525183"].owner == "Neon One, LLC"


# --- auto-select ONLY on exact owner-name match (the labor-saving rule) ----

def test_auto_selects_the_registration_whose_owner_matches_the_company():
    recs = parse_justia_results(JUSTIA_RESULTS)
    res = select_registrations(recs, brand="Neon One", owner="Neon One, LLC")
    assert res.chosen is not None
    assert res.chosen.serial_number == "99525183"     # NOT the IDG mark
    assert res.needs_human_selection is False


def test_owner_match_ignores_case_and_punctuation():
    recs = parse_justia_results(JUSTIA_RESULTS)
    res = select_registrations(recs, brand="neon one", owner="NEON ONE LLC")
    assert res.chosen.serial_number == "99525183"


def test_no_owner_match_stays_human_no_autofill():
    recs = parse_justia_results(JUSTIA_RESULTS)
    res = select_registrations(recs, brand="Neon One", owner="Wild Apricot, Inc.")
    assert res.chosen is None
    assert res.needs_human_selection is True


def test_without_owner_two_same_wordmarks_stay_ambiguous():
    recs = parse_justia_results(JUSTIA_RESULTS)     # two NEON ONE hits, no owner given
    res = select_registrations(recs, brand="Neon One")
    assert res.chosen is None
    assert res.needs_human_selection is True


# --- TSDR status parse: registration number + live/registered -------------

def test_parse_tsdr_status_reads_reg_number_and_registered_live():
    s = parse_tsdr_status(TSDR_TEXT)
    assert s["registration_number"] == "8322586"
    assert s["registered"] is True
    assert s["live"] is True
    assert s["wordmark"] == "NEON ONE"
