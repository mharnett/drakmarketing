"""Anchor tests for the brand-mark-in-ad-text detector.

The detector answers ONE question: does the trademark appear in the ad's
visible copy (headlines / descriptions / display URL)? It must:
  - match case-insensitively and across spacing/punctuation variants,
  - NOT match non-adjacent token coincidences ("neon signs ... one-time"),
  - flag the mark owner's own ads (which contain the mark legitimately),
  - report which fields matched and the matched substrings (for highlighting).
It deliberately does NOT decide infringement — that's the classifier's job.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.detector import find_mark_in_ad, MarkMatch  # noqa: E402

OWNER_DOMAINS = ["neonone.com", "neoncrm.com"]


def _ad(**kw):
    base = {
        "advertiser": "Some Advertiser",
        "headlines": [],
        "descriptions": [],
        "display_url": "",
        "final_url": "https://example.com/",
    }
    base.update(kw)
    return base


# --- exact / case / variant matching -------------------------------------

def test_exact_mark_in_headline_of_competitor_ad():
    m = find_mark_in_ad(
        _ad(advertiser="Wild Apricot",
            headlines=["Neon One Alternative", "Try Wild Apricot"],
            final_url="https://www.wildapricot.com/lp/neon-alternative"),
        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert "headlines" in m.fields
    assert m.match_type == "exact"
    assert m.is_own_brand is False
    assert any("neon one" in t.lower() for t in m.matched_text)


def test_case_insensitive_is_still_exact():
    m = find_mark_in_ad(_ad(headlines=["the best neon one competitor"]),
                        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert m.match_type == "exact"


def test_spacing_variant_is_variant_match():
    m = find_mark_in_ad(_ad(headlines=["NeonOne Reviews"]),
                        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert m.match_type == "variant"


def test_hyphen_variant_is_variant_match():
    m = find_mark_in_ad(_ad(descriptions=["Switch from Neon-One today"]),
                        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert "descriptions" in m.fields
    assert m.match_type == "variant"


# --- non-matches / false friends -----------------------------------------

def test_no_mark_present_is_no_match():
    m = find_mark_in_ad(_ad(headlines=["Best Nonprofit CRM Software"]),
                        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is False
    assert m.match_type == "none"
    assert m.fields == []


def test_non_adjacent_tokens_do_not_match():
    # "neon" and "one" appear but are not the mark — must NOT match.
    m = find_mark_in_ad(
        _ad(descriptions=["Neon signs and one-time donations for your gala"]),
        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is False


def test_mark_as_prefix_of_larger_word_does_not_match():
    m = find_mark_in_ad(_ad(headlines=["Neon Oneness Collective"]),
                        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is False


# --- own-brand exclusion --------------------------------------------------

def test_owner_own_ad_is_flagged_own_brand():
    m = find_mark_in_ad(
        _ad(advertiser="Neon One",
            headlines=["Neon One — Nonprofit CRM"],
            display_url="neonone.com",
            final_url="https://www.neonone.com/products/"),
        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True          # the mark IS in the copy
    assert m.is_own_brand is True     # ...but it's the owner's own ad


# --- field coverage & custom variants ------------------------------------

def test_match_in_display_url_path():
    m = find_mark_in_ad(
        _ad(display_url="wildapricot.com/neon-one-alternative"),
        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert "display_url" in m.fields


def test_custom_variant_list_matches():
    m = find_mark_in_ad(_ad(headlines=["Better than NeonCRM"]),
                        mark="Neon One", variants=["NeonCRM"],
                        owner_domains=OWNER_DOMAINS)
    assert m.matched is True
    assert m.match_type == "variant"


def test_multiple_fields_report_all():
    m = find_mark_in_ad(
        _ad(headlines=["Neon One Alternative"],
            descriptions=["Cheaper than Neon One"]),
        mark="Neon One", owner_domains=OWNER_DOMAINS)
    assert set(m.fields) == {"headlines", "descriptions"}


# --- aggregate shape ------------------------------------------------------

def test_aggregate_match_count_over_fixture_batch():
    ads = [
        _ad(headlines=["Neon One Alternative"], final_url="https://a.com"),   # match
        _ad(headlines=["NeonOne pricing"], final_url="https://b.com"),        # variant match
        _ad(headlines=["Best Nonprofit CRM"], final_url="https://c.com"),     # no match
        _ad(headlines=["Neon signs one time"], final_url="https://d.com"),    # false friend, no match
        _ad(headlines=["Neon One"], final_url="https://www.neonone.com"),     # own brand (matched but excluded)
    ]
    results = [find_mark_in_ad(a, mark="Neon One", owner_domains=OWNER_DOMAINS) for a in ads]
    matched = [r for r in results if r.matched and not r.is_own_brand]
    assert len(matched) == 2  # only the two genuine competitor mentions
