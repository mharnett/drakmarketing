"""Integration/shape tests for candidate selection + draft package assembly.

This is the composition seam: detector match + own-brand flag + classifier bucket
must combine so that ONLY a matched, non-owner, COMPETITIVE ad becomes a
complaint candidate. A wiring bug here passes every unit test upstream, so the
key test asserts the aggregate selection over a mixed batch.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.detector import MarkMatch  # noqa: E402
from scripts.classifier import Bucket  # noqa: E402
from scripts.dossier import (  # noqa: E402
    select_candidates, looks_like_dki, build_draft_package,
)


def _assessed(advertiser, matched, own, bucket, landing="https://x.com",
              dki=False, trigger="neon one"):
    return {
        "ad": {"advertiser": advertiser, "final_url": landing,
               "trigger_query": trigger, "screenshot_path": f"/s/{advertiser}.png",
               "headlines": ["Neon One Alternative"], "geo": "United States"},
        "match": MarkMatch(matched=matched, fields=["headlines"],
                           matched_text=["Neon One"],
                           match_type="exact", is_own_brand=own),
        "bucket": bucket,
        "landing_url": landing,
        "dki_suspected": dki,
    }


def test_only_competitive_non_owner_matches_are_candidates():
    batch = [
        _assessed("Wild Apricot", True, False, Bucket.COMPETITIVE),      # candidate
        _assessed("ResellerCo", True, False, Bucket.RESELLER),           # permitted
        _assessed("Neon One", True, True, Bucket.COMPETITIVE),           # own brand
        _assessed("NoMatchCo", False, False, Bucket.AMBIGUOUS),          # no mark in copy
        _assessed("ReviewSite", True, False, Bucket.INFORMATIONAL),      # permitted
    ]
    cands = select_candidates(batch)
    assert len(cands) == 1
    assert cands[0].advertiser == "Wild Apricot"


def test_permitted_and_ambiguous_never_selected():
    for bucket in (Bucket.RESELLER, Bucket.INFORMATIONAL,
                   Bucket.PARTNER_AFFILIATE, Bucket.AMBIGUOUS, Bucket.OWN_BRAND):
        batch = [_assessed("Advertiser", True, False, bucket)]
        assert select_candidates(batch) == []


def test_dki_heuristic_flags_query_echo():
    assert looks_like_dki(["Neon One"], "neon one reviews") is True
    assert looks_like_dki(["Neon One"], "membership software") is False


def test_dki_flag_propagates_to_candidate():
    batch = [_assessed("Wild Apricot", True, False, Bucket.COMPETITIVE,
                       dki=True, trigger="neon one reviews")]
    cands = select_candidates(batch)
    assert cands[0].dki_suspected is True


# --- draft package assembly -----------------------------------------------

def test_draft_package_shape_and_human_gate():
    batch = [_assessed("Wild Apricot", True, False, Bucket.COMPETITIVE,
                       landing="https://wildapricot.com/lp")]
    cands = select_candidates(batch)
    pkg = build_draft_package(
        brand="Neon One",
        owner="Neon One, LLC",
        registration_numbers=["6123456"],
        needs_human_selection=False,
        candidates=cands,
        complainant={"relationship": "authorized_agent",
                     "name": "Drak Marketing", "email": "mark@drakmarketing.com"},
        geos=["United States"],
    )
    assert pkg["scope"] == "specific_advertisers"          # never "all advertisers"
    assert pkg["auto_submit"] is False                     # human submits, always
    assert pkg["trademark"]["registration_numbers"] == ["6123456"]
    assert len(pkg["ads"]) == 1
    block = pkg["ads"][0]
    assert block["advertiser"] == "Wild Apricot"
    assert block["trigger_query"]
    assert block["screenshot_path"]
    assert block["landing_url"] == "https://wildapricot.com/lp"


def test_draft_surfaces_registration_selection_warning():
    pkg = build_draft_package(
        brand="Neon One", owner="Neon One, LLC", registration_numbers=[],
        needs_human_selection=True, candidates=[],
        complainant={"relationship": "authorized_agent", "name": "x", "email": "y"},
        geos=["United States"],
    )
    assert pkg["needs_human_selection"] is True
    assert pkg["warnings"]  # must warn a human to pick/confirm the registration
