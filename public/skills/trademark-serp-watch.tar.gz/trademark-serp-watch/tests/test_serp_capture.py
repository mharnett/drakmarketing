"""Contract tests for the SERP capture adapter.

The HTTP call is a seam; the tested logic is (a) parsing a provider response into
normalized CapturedAd rows and (b) capture-health — which must refuse to report
"clean" when every query came back empty (that reads as capture failure, not
absence of infringement).
"""
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.serp_capture import (  # noqa: E402
    CapturedAd, parse_serpapi_ads, capture_health, require_serpapi_key,
    resolve_fetch, fetch_serpapi, fetch_proxy, proxy_url,
    DEFAULT_LOCATIONS, dedupe_ads,
)

# Minimal SerpAPI-shaped Google results payload (the fields we consume).
SERPAPI_FIXTURE = {
    "search_metadata": {"status": "Success"},
    "ads": [
        {
            "position": 1,
            "block_position": "top",
            "title": "Neon One Alternative | Wild Apricot",
            "link": "https://www.wildapricot.com/lp/neon-alternative",
            "displayed_link": "www.wildapricot.com/membership",
            "description": "Membership software nonprofits love. Try free.",
            "source": "Wild Apricot",
        },
        {
            "position": 2,
            "block_position": "bottom",
            "title": "Nonprofit CRM Software",
            "link": "https://www.example-crm.com/",
            "displayed_link": "www.example-crm.com",
            "description": "All-in-one fundraising.",
            "source": "Example CRM",
        },
    ],
}


def test_parse_returns_normalized_ads_with_trigger_query():
    ads = parse_serpapi_ads(SERPAPI_FIXTURE, trigger_query="neon one reviews")
    assert len(ads) == 2
    a = ads[0]
    assert isinstance(a, CapturedAd)
    assert a.advertiser == "Wild Apricot"
    assert a.display_url == "www.wildapricot.com/membership"
    assert a.final_url == "https://www.wildapricot.com/lp/neon-alternative"
    assert a.trigger_query == "neon one reviews"
    assert a.position == "top"
    # title / description land where the detector scans them
    assert any("Neon One" in h for h in a.headlines)
    assert any("Membership software" in d for d in a.descriptions)


def test_parse_missing_ads_key_returns_empty():
    assert parse_serpapi_ads({"search_metadata": {"status": "Success"}},
                             trigger_query="q") == []


def test_capture_health_all_zero_is_suspect_not_clean():
    per_query = {"neon one": [], "neon one reviews": [], "neon one pricing": []}
    h = capture_health(per_query)
    assert h["status"] == "suspect_zero"
    assert h["total_ads"] == 0
    assert h["queries_with_ads"] == 0
    assert "warn" in h and h["warn"]  # must carry a do-not-interpret-as-clean warning


def test_capture_health_partial_is_ok_with_counts():
    per_query = {
        "neon one": [CapturedAd(advertiser="X", headlines=["Neon One"], descriptions=[],
                                display_url="x.com", final_url="https://x.com",
                                trigger_query="neon one", position="top")],
        "neon one pricing": [],
    }
    h = capture_health(per_query)
    assert h["status"] == "ok"
    assert h["total_ads"] == 1
    assert h["queries_with_ads"] == 1
    assert h["queries_total"] == 2


# --- key resolution: BYO-key, never shared --------------------------------

def test_require_key_returns_explicit_key():
    assert require_serpapi_key(api_key="abc123", env={}) == "abc123"


def test_require_key_reads_from_env():
    assert require_serpapi_key(api_key=None, env={"SERPAPI_KEY": "xyz789"}) == "xyz789"


def test_require_key_missing_raises_actionable_setup_message():
    with pytest.raises(RuntimeError) as ei:
        require_serpapi_key(api_key=None, env={})
    msg = str(ei.value)
    assert "SERPAPI_KEY" in msg          # names the var
    assert "serpapi.com" in msg          # tells them where to get one
    assert "export SERPAPI_KEY" in msg   # tells them how to set it
    assert "own" in msg.lower()          # makes clear it's their own, not shared


# --- fetch selection: hosted proxy by default, BYO if a key is present ------

def test_resolve_fetch_uses_proxy_when_no_key():
    # Default path for downloaded skills: no key -> hosted proxy (operator's key).
    assert resolve_fetch(env={}) is fetch_proxy


def test_resolve_fetch_uses_own_key_when_present():
    # Power user / dev with their own key uses it directly (cheaper for operator).
    assert resolve_fetch(env={"SERPAPI_KEY": "abc"}) is fetch_serpapi


def test_proxy_url_prefers_env_override_then_default():
    assert proxy_url(env={"SERPWATCH_PROXY_URL": "https://my.proxy/serp"}) == \
        "https://my.proxy/serp"
    # falls back to the baked-in default (non-empty) when unset
    assert proxy_url(env={}).startswith("http")


# --- geo granularity: ad auctions need city-level locations ----------------

def test_default_locations_are_city_level_not_country():
    # Regression: a bare country ("United States") returns ZERO ads from SerpAPI;
    # ad auctions only trigger at city granularity. Defaults must be city-level.
    assert DEFAULT_LOCATIONS
    assert "United States" not in DEFAULT_LOCATIONS
    assert all(loc.count(",") >= 2 for loc in DEFAULT_LOCATIONS)  # "City, State, Country"


def _ad(advertiser, title, url, geo):
    return CapturedAd(advertiser=advertiser, headlines=[title], descriptions=[],
                      display_url="", final_url=url, trigger_query="neon one",
                      position="top", geo=geo)


def test_dedupe_ads_collapses_same_ad_seen_in_multiple_cities():
    a1 = _ad("WildApricot", "WildApricot vs Neon CRM", "https://wa.com/vs-neon", "Austin")
    a2 = _ad("WildApricot", "WildApricot vs Neon CRM", "https://wa.com/vs-neon", "Chicago")
    a3 = _ad("Neon One", "Neon One CRM", "https://neonone.com", "Austin")
    out = dedupe_ads([a1, a2, a3])
    assert len(out) == 2   # the two identical WildApricot renders collapse to one


def test_dedupe_keeps_distinct_creatives_from_same_advertiser():
    a1 = _ad("WildApricot", "vs Neon CRM - Simple", "https://wa.com/vs-neon", "Austin")
    a2 = _ad("WildApricot", "Neon CRM Not Cutting It?", "https://wa.com/vs-neon", "Austin")
    assert len(dedupe_ads([a1, a2])) == 2  # different headline = different ad
