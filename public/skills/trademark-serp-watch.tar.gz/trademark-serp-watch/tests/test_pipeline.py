"""Tests for the query-set generator and the capture->detect flagging step."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from scripts.serp_capture import CapturedAd  # noqa: E402
from scripts.pipeline import build_query_set, flag_ads  # noqa: E402


def test_query_set_covers_brand_intents_and_includes_brand():
    qs = build_query_set("Neon One")
    assert "Neon One" in qs
    assert "Neon One reviews" in qs
    assert "Neon One alternative" in qs
    assert all("Neon One" in q for q in qs)
    assert len(qs) == len(set(qs))            # deduped
    assert len(qs) >= 6                        # meaningful intent coverage


def test_query_set_extra_terms_are_appended():
    qs = build_query_set("Neon One", extra_terms=["Neon One discount"])
    assert "Neon One discount" in qs


def _cad(advertiser, headline, final_url):
    return CapturedAd(advertiser=advertiser, headlines=[headline], descriptions=[],
                      display_url="", final_url=final_url, trigger_query="neon one",
                      position="top")


def test_flag_ads_keeps_only_competitor_mark_mentions():
    ads = [
        _cad("Wild Apricot", "Neon One Alternative", "https://wildapricot.com"),  # keep
        _cad("Neon One", "Neon One CRM", "https://www.neonone.com"),              # own brand
        _cad("Other CRM", "Best Nonprofit CRM", "https://other.com"),             # no mark
    ]
    flagged = flag_ads(ads, mark="Neon One", owner_domains=["neonone.com"])
    assert len(flagged) == 1
    assert flagged[0]["ad"].advertiser == "Wild Apricot"
    assert flagged[0]["match"].matched is True
    assert flagged[0]["match"].is_own_brand is False


def test_flag_ads_accepts_dict_ads_too():
    ads = [{"advertiser": "Wild Apricot", "headlines": ["Neon One Alternative"],
            "descriptions": [], "display_url": "", "final_url": "https://wildapricot.com",
            "trigger_query": "neon one"}]
    flagged = flag_ads(ads, mark="Neon One", owner_domains=["neonone.com"])
    assert len(flagged) == 1
